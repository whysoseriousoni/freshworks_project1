# freshworks_project1
this is created by Pradeep.E from Misrimal Navajee Munoth Jain Engineering College. Ph. No: 9551371278

project is developed in " java with maven " and tested in Windows environment with the hope of work ability in linux(will test later).
